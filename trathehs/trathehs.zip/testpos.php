<?php
$pos=strpos("BD0023D","bd");
echo "Vị trí tìm thấy : ".strpos("Kóp , Xã Kon Gang , Huyện Đăk Đoa , Tỉnh Gia Lai","Gang");
?>