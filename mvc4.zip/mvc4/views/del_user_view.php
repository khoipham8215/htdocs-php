<?php
echo 'Del user';
?>