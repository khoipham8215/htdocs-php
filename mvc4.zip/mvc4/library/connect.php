<?php
$conn = mysqli_connect('localhost', 'root', '', 'dulieuc12');
$lang = mysqli_query($conn, "SET NAMES 'utf8'");
?>