<?php
include_once('views/add_user_view.php');
?>