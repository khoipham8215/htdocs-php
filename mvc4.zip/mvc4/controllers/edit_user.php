<?php
include_once('views/edit_user_view.php');
?>