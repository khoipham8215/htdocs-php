<?php
include_once('views/del_user_view.php');
?>