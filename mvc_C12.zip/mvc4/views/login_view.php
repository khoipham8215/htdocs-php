

<div class="content">
		<div id="tieude">Đăng nhập vào hệ thống !</div>
		<div id="flg">
		<form method="post" action="index.php?controller=login">
			<label id="hint"><i> (Tên đăng nhập và mật khẩu mặc định là mã đơn vị vd : 'TA1000A'<br/> nếu chưa có liên hệ BHXH để cung cấp) </i></label><br/><table class="tblg"><tr>
			<td><label>Tên đăng nhập </label></td><td><input type="text" name="user" /></td></tr><tr>
			<td><label>Mật khẩu </label></td><td><input type="password" name="pwd" /></td></tr>
			<tr ><td colspan='2'><input type="submit" name="btlg" class ="btlg" onClick="login()" /> </tr></table>
		</form>
		</div>
</div>