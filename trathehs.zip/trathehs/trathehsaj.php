<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<?php

header('Content-Type: text/html; charset=utf-8');
function vn_to_str ($str){

$unicode = array(
 
'a'=>'á|à|ả|ã|ạ|ă|ắ|ặ|ằ|ẳ|ẵ|â|ấ|ầ|ẩ|ẫ|ậ',
 
'd'=>'đ',
 
'e'=>'é|è|ẻ|ẽ|ẹ|ê|ế|ề|ể|ễ|ệ',
 
'i'=>'í|ì|ỉ|ĩ|ị',
 
'o'=>'ó|ò|ỏ|õ|ọ|ô|ố|ồ|ổ|ỗ|ộ|ơ|ớ|ờ|ở|ỡ|ợ',
 
'u'=>'ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự',
 
'y'=>'ý|ỳ|ỷ|ỹ|ỵ',
 
'A'=>'Á|À|Ả|Ã|Ạ|Ă|Ắ|Ặ|Ằ|Ẳ|Ẵ|Â|Ấ|Ầ|Ẩ|Ẫ|Ậ',
 
'D'=>'Đ',
 
'E'=>'É|È|Ẻ|Ẽ|Ẹ|Ê|Ế|Ề|Ể|Ễ|Ệ',
 
'I'=>'Í|Ì|Ỉ|Ĩ|Ị',
 
'O'=>'Ó|Ò|Ỏ|Õ|Ọ|Ô|Ố|Ồ|Ổ|Ỗ|Ộ|Ơ|Ớ|Ờ|Ở|Ỡ|Ợ',
 
'U'=>'Ú|Ù|Ủ|Ũ|Ụ|Ư|Ứ|Ừ|Ử|Ữ|Ự',
 
'Y'=>'Ý|Ỳ|Ỷ|Ỹ|Ỵ',
 
);
 
foreach($unicode as $nonUnicode=>$uni){
 
$str = preg_replace("/($uni)/i", $nonUnicode, $str);
 
}
$str = str_replace(' ','',$str);
 
return $str;
 
}



require_once 'database.php';
$db= new Database();
$db->connect();

$stt=1;
if($_POST['loaitc']){
	echo "Loại tra cứu : ".$_POST['loaitc']." Năm tra cứu : ".$_POST['namps'];
	$sql="select * from dsthe where Hanthe like '".$_POST['namps']."'";
	$manghs=$db->query1($sql,MYSQLI_ASSOC);
	$dltra=explode("\n",$_POST['dltra']);
	$mangkq=[];
	$mangkt=[];
	$bd=time();
	for($i=0;$i<(count($dltra)-1);$i++){
		if($dltra!=""){
			$kq=tratheBHYT1($dltra[$i],$manghs,$stt);
			if($kq!=null){
				array_push($mangkq,$kq);
				//echo "<br/>Tìm thấy : ".$dltra[$i];
			}else { 
				array_push($mangkt,$i);
				//echo "<br/>Không Tìm thấy : ".$dltra[$i];
			}
			//if(!empty(tratheBHYT1($dltra[$i],$manghs))){
			//tratheBHYT1($dltra[$i],$manghs,$stt);
			//$stt++;
			//array_push($mangkq,tratheBHYT1($dltra[$i],$manghs));
			//$mangkq.push(tratheBHYT1($dltra[$i],$manghs));
			//}else echo "<br/>Không tìm thấy : ".$i.$dltra[$i];
		}
		//echo "Tra thẻ :".$dltra[$i]."\n";
	}
	echo "<br/>Tổng thời gian tra ".(count($dltra)-1)." thẻ là ".(time()-$bd)." giây";
	// in kết quả tra được
	
	echo "<br/><b>Tổng số có thẻ : </b>".count($mangkq);
	echo "<table><tr><th>STT</th><th>Mã đơn vị</th><th>Số BHXH</th><th>Mã thẻ</th><th>Họ tên</th><th>Ngày Sinh</th><th>Hạn thẻ</th></tr>";
	for($i=0;$i<count($mangkq);$i++){
		echo "<tr><td>".($i+1)."</td><td>".($manghs[$mangkq[$i]]['maDvi'])."</td><td>".($manghs[$mangkq[$i]]['soBhxh'])."</td><td>".($manghs[$mangkq[$i]]['soKcb'])."</td><td>".($manghs[$mangkq[$i]]['hoTen'])."</td><td>".($manghs[$mangkq[$i]]['ngaySinh'])."</td><td>".($manghs[$mangkq[$i]]['Hanthe'])."</td></tr>";
		//echo "<p>".($i+1)." - ".$manghs[$mangkq[$i]]['id']." - ".$manghs[$mangkq[$i]]['maDvi']." - ".$manghs[$mangkq[$i]]['soBhxh']." - ".$manghs[$mangkq[$i]]['soKcb']." - ".$manghs[$mangkq[$i]]['Hanthe']." - ".$manghs[$mangkq[$i]]['hoTen']."-".$manghs[$mangkq[$i]]['ngaySinh']."</p>";
	}
	echo "</table>";
	echo "<br/><b>Tổng số không tìm thấy : </b>".count($mangkt);
	for($i=0;$i<count($mangkt);$i++){
		echo "<p>".$dltra[$mangkt[$i]]."</p>";
	}
	//print_r($mangkq);
	//print_r($mangkt);
}
function tratheBHYT1($dltra,$manghs,$stt){
	$dl=explode("-",$dltra);
	$hoten=str_replace([' ',"'"],'',trim($dl[0]));
	$ngaysinh=trim($dl[1]);
	//echo $hoten.$ngaysinh;
	$kq=TRUE;
	$i=0;
	//$j=1;
	while($kq and $i<count($manghs)){
		//$pos1=0;$pos2=0;
		$ht=str_replace([' ',"'"],'',$manghs[$i]['hoTen']);
		//$pos1=strpos($ht,$hoten);
		$pos2=strpos($manghs[$i]['ngaySinh'],$ngaysinh);
		if($hoten==$ht and $ngaysinh==$manghs[$i]['ngaySinh']){
		//$mangkq.push($manghs[$i]);
		return $manghs[$i]['id'];
		//echo "<p>".$stt." - ".$manghs[$i]['id']." - ".$manghs[$i]['maDvi']." - ".$manghs[$i]['soBhxh']." - ".$manghs[$i]['soKcb']." - ".$manghs[$i]['Hanthe']." - ".$manghs[$i]['hoTen']."-".$manghs[$i]['ngaySinh']."</p>";
		$kq=FALSE;
		}else $i++;
		//echo str_replace([' '],'',$manghs[$i]['hoTen']);
	}
	//$j++;
	if($kq){
		//echo "<br/>Không tìm thấy ! ".$hoten.$ngaysinh;
		//array_push($mangkt,$dltra);
		//return false;
	}
}
//echo $dltra[0].$dltra[1];
//var_dump(mangtra);
//echo $manghs[0]["hoTen"].$manghs[0]["ngaySinh"];
?>